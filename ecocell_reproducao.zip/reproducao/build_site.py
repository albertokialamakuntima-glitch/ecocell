import os,json,re,glob,numpy as np,pandas as pd,shapely,pycountry
import pycountry_convert as pc
from shapely.geometry import shape,mapping,MultiPolygon,box
from shapely.ops import transform
from shapely.strtree import STRtree
PT={'Algeria': 'Argélia', 'Benin': 'Benim', 'Botswana': 'Botsuana', 'Cameroon': 'Camarões', 'Central African Rep.': 'Rep. Centro-Africana', 'Chad': 'Chade', 'Comoros': 'Comores', 'Dem. Rep. Congo': 'RD Congo', 'Djibouti': 'Jibuti', 'Egypt': 'Egipto', 'Eq. Guinea': 'Guiné Equatorial', 'Eritrea': 'Eritreia', 'eSwatini': 'Essuatíni', 'Ethiopia': 'Etiópia', 'Gabon': 'Gabão', 'Gambia': 'Gâmbia', 'Ghana': 'Gana', 'Guinea': 'Guiné', 'Guinea-Bissau': 'Guiné-Bissau', "Côte d'Ivoire": 'Costa do Marfim', 'Kenya': 'Quénia', 'Lesotho': 'Lesoto', 'Liberia': 'Libéria', 'Libya': 'Líbia', 'Madagascar': 'Madagáscar', 'Malawi': 'Maláui', 'Mauritania': 'Mauritânia', 'Mauritius': 'Maurícia', 'Morocco': 'Marrocos', 'Mozambique': 'Moçambique', 'Namibia': 'Namíbia', 'Niger': 'Níger', 'Nigeria': 'Nigéria', 'Rwanda': 'Ruanda', 'São Tomé and Principe': 'São Tomé e Príncipe', 'Seychelles': 'Seicheles', 'Sierra Leone': 'Serra Leoa', 'Somalia': 'Somália', 'Somaliland': 'Somalilândia', 'South Africa': 'África do Sul', 'S. Sudan': 'Sudão do Sul', 'Sudan': 'Sudão', 'Tanzania': 'Tanzânia', 'Tunisia': 'Tunísia', 'W. Sahara': 'Saara Ocidental', 'Zambia': 'Zâmbia', 'Zimbabwe': 'Zimbábue'}
d=pd.read_csv('cells.csv').drop_duplicates(['lat','lon']).reset_index(drop=True)
META=json.load(open('meta.json'));from datetime import date;DAYS=(date.fromisoformat(META['end'])-date.fromisoformat(META['start'])).days
if 'recent' not in d: d['recent']=np.nan
print('células fundidas',len(d))
def fix(s):
    parts=list(s.geoms) if s.geom_type=='MultiPolygon' else [s]; out=[]
    for p in parts:
        b=p.bounds
        if b[2]-b[0]<=180: out.append(p); continue
        q=transform(lambda x,y,z=None:(np.where(np.asarray(x)<0,np.asarray(x)+360,x),y),p).buffer(0)
        for bx,sh in ((box(0,-90,180,90),0),(box(180,-90,360,90),-360)):
            r=q.intersection(bx)
            if r.is_empty: continue
            r=transform(lambda x,y,z=None:(np.asarray(x)+sh,y),r)
            out+=[x for x in (r.geoms if hasattr(r,'geoms') else [r]) if x.geom_type=='Polygon' and x.area>0]
    return MultiPolygon(out)
AIRS_FILE=os.environ.get('AIRS_FILE','airs_trends.json')
g=json.load(open('world.json')); feats=[f for f in g['features'] if f['properties']['name']!='Antarctica']
shp=[fix(shape(f['geometry'])) for f in feats]; names=[f['properties']['name'] for f in feats]
# continentes
CONT=[('África',[-18,-35,52,38],8),('Europa',[-25,34,45,72],3),('Ásia',[25,-11,180,78],30),('América do Norte',[-170,7,-50,83],30),('América do Sul',[-92,-56,-34,13],10),('Oceânia',[110,-48,180,-1],20)]
M={'AF':0,'EU':1,'AS':2,'NA':3,'SA':4,'OC':5}; ASIA={'RU','KZ','GE','AM','AZ','CY','TR'}
def cont_of(f,s):
    try:
        a2=pycountry.countries.get(numeric=str(f.get('id')).zfill(3)).alpha_2
        return 2 if a2 in ASIA else M[pc.country_alpha2_to_continent_code(a2)]
    except Exception:
        rp=s.representative_point()
        for k in [0,1,2,3,4,5]:
            b=CONT[k][1]
            if b[0]<=rp.x<=b[2] and b[1]<=rp.y<=b[3]: return k
        return 2
ARID=set("Algeria,Libya,Egypt,Niger,Mali,Chad,Mauritania,W. Sahara,Sudan,Saudi Arabia,Iraq,Iran,Afghanistan,Pakistan,Oman,Yemen,United Arab Emirates,Kuwait,Qatar,Jordan,Syria,Israel,Palestine,Turkmenistan,Uzbekistan,Mongolia,Kazakhstan,Australia,Namibia,Botswana,Somalia,Somaliland,Djibouti,Eritrea,Morocco,Tunisia,Bahrain,Lebanon".split(','))
SEMI=set("China,India,South Africa,Kenya,Ethiopia,Argentina,Turkey,Spain,Burkina Faso,S. Sudan,Zimbabwe,Lesotho,Tajikistan,Kyrgyzstan,Azerbaijan,Armenia,Greece,Portugal,Chile,Paraguay,Uganda,Tanzania,Zambia,Angola,Mozambique,Madagascar,Senegal,Gambia,Guinea-Bissau,Benin,Togo,Nigeria".split(','))
FOREST=set("Brazil,Colombia,Venezuela,Peru,Ecuador,Bolivia,Suriname,Guyana,Dem. Rep. Congo,Congo,Gabon,Cameroon,Central African Rep.,Eq. Guinea,Indonesia,Malaysia,Papua New Guinea,Myanmar,Laos,Cambodia,Vietnam,Thailand,Russia,Sweden,Finland,Norway,Canada,Liberia,Sierra Leone,Guinea,Côte d'Ivoire,Ghana,Japan,Philippines,Panama,Costa Rica,Nicaragua,Honduras,Guatemala,Belize".split(','))
def vclass(n): return 4 if n=='Greenland' else 0 if n in ARID else 1 if n in SEMI else 3 if n in FOREST else 2
K=[cont_of(f,s) for f,s in zip(feats,shp)]
# atribuir células
pts=shapely.points(d.lon.values,d.lat.values); tree=STRtree(shp)
ci=np.full(len(d),-1); sea=np.zeros(len(d),int)
a,b=tree.query(pts,predicate='within'); ci[a[::-1]]=b[::-1]
rest=np.where(ci<0)[0]
a,b=tree.query_nearest(pts[rest],max_distance=2,all_matches=False); ci[rest[a]]=b; sea[rest[a]]=1
d['ci']=ci; d['sea']=sea
d['an']=d['mean']-d.groupby('lat')['mean'].transform('median')
d['chg']=d.slope*DAYS/d['mean']*100
d=d[d.ci>=0].reset_index(drop=True)
d['ch']=d.chg.where(d.chg.abs()<=3)
z=lambda s:(s-s.mean())/s.std()
d['sc']=z(d.an)+z(d.ch).fillna(0); d['rk']=d.sc.rank(ascending=False).astype(int)
q1,q2=d.an.quantile([1/3,2/3]); d['lv']=np.where(d.an<=q1,0,np.where(d.an<=q2,1,2))
def mainb(s):
    ps=list(s.geoms) if s.geom_type=='MultiPolygon' else [s]; wa=lambda p:p.area*np.cos(np.radians(p.centroid.y)); m=max(wa(p) for p in ps)
    bs=np.array([p.bounds for p in ps if wa(p)>=.25*m])
    return [max(-179.9,round(float(bs[:,0].min())-.5,1)),max(-84,round(float(bs[:,1].min())-.5,1)),min(179.9,round(float(bs[:,2].max())+.5,1)),min(84,round(float(bs[:,3].max())+.5,1))]
def expected(s):
    x0,y0,x1,y1=s.bounds; X,Y=np.meshgrid(np.arange(np.floor(x0)+.5,x1,1.0),np.arange(np.ceil(y0),y1,1.0))
    return int(shapely.contains_xy(s,X.ravel(),Y.ravel()).sum())
cs=[]
for i,n in enumerate(names):
    s=d[d.ci==i]; l=s[s.sea==0]
    cs.append({'en':n,'n':PT.get(n,n),'k':K[i],'v':vclass(n),'b':mainb(shp[i]),'ne':expected(shp[i]) if len(d[d.ci==i]) else 0,'a':round(shp[i].area,1),'nc':len(s),'nl':len(l),
      'ma':None if l.empty else round(float(l.an.mean()),1),'hi':int(round(100*(s.lv==2).mean())) if len(s) else 0})
top=[];cc={}
for ix in d.sort_values('rk').index:
    c=int(d.ci[ix])
    if pd.isna(d.ch[ix]) or abs(d.lat[ix])>60: continue
    if cc.get(c,0)<2: top.append(int(ix)); cc[c]=cc.get(c,0)+1
    if len(top)==30: break
cells=[[r.lat,r.lon,round(r.mean,1),None if pd.isna(r.ch) else round(r.ch,2),round(r.an,1),round(r.sc,2),int(r.lv),int(r.sea),int(r.ci),int(r.rk),None if pd.isna(r.recent) else round(r.recent-r.mean,1)] for r in d.itertuples()]
def rd(x): return [rd(i) for i in x] if isinstance(x,(list,tuple)) else round(x,2)
gf=[]
for i,(s,n) in enumerate(zip(shp,names)):
    m=mapping(s.simplify(0.03 if cs[i]['nc'] and K[i]==0 else 0.1)); big=max(s.geoms,key=lambda p:p.area); rp=big.representative_point()
    gf.append({'type':'Feature','properties':{'i':i,'lon':round(rp.x,2),'lat':round(rp.y,2)},'geometry':{'type':m['type'],'coordinates':rd(m['coordinates'])}})
# ---- NASA AIRS (opcional)
AIRS=None;AC={};AK=[]
if os.path.exists(AIRS_FILE):
    raw=open(AIRS_FILE,'rb').read()
    try: AJ=json.loads(raw.decode('utf-8'))
    except UnicodeDecodeError: AJ=json.loads(raw.decode('cp1252'))
    cl=np.array([r[:8] for r in AJ['celulas']]); wt=np.cos(np.radians(cl[:,0])); G=float(AJ['globais']['slope']) if 'globais' in AJ else float((cl[:,2]*wt).sum()/wt.sum())
    def _fix(k):
        try: return k.encode('cp1252').decode('utf-8')
        except Exception: return k
    AJ['paises']={_fix(k):v for k,v in AJ['paises'].items()}
    def mk_air(p):
        f=float(np.sqrt((1+p['r1'])/(1-p['r1']))); lo=p['slope']-(p['slope']-p['lo'])*f; hi=p['slope']+(p['hi']-p['slope'])*f
        return dict(s=round(p['slope'],2),lo=round(lo,2),hi=round(hi,2),rel=round(p['slope']-G,2),pd=round(p['pct_decada'],2),q=p['q'],r1=p['r1'],
                    sa=int(p['q']<0.05 and lo>0),sr=int(G<lo or G>hi),an=p['anos'],se=p['serie_anual'])
    for i,c in enumerate(cs):
        p=AJ['paises'].get(c['en']); c['air']=mk_air(p) if p else None
    AK=[(mk_air(AJ['continentes'][nm]) if nm in AJ.get('continentes',{}) else None) for nm,_,_ in CONT]
    import math
    _need={f"{math.floor(la)+.5},{lo}" for la,lo in zip(d.lat,d.lon)}
    AC={}
    for r in AJ['celulas']:
        if f"{r[0]},{r[1]}" not in _need: continue
        if len(r)>=10 and r[9]:
            f_=float(np.sqrt((1+r[8])/(1-r[8]))); lo_=r[2]-(r[2]-r[3])*f_; hi_=r[2]+(r[4]-r[2])*f_
            AC[f"{r[0]},{r[1]}"]=dict(s=round(r[2],2),lo=round(lo_,2),hi=round(hi_,2),q=r[6],sa=int(r[6]<0.05 and lo_>0),sr=int(G<lo_ or G>hi_),r1=r[8],se=r[9])
    _v=[x for c in list(cs)+[{'air':k} for k in AK] if c.get('air') for x in c['air']['se'] if x is not None]
    AIRS=dict(yr=[round(min(_v)),round(max(_v))],gse=AJ.get('serie_global'),anos=AJ.get('anos_celulas'),G=round(G,2),periodo=AJ['periodo'],inst=AJ['instrumento'],nivel=AJ['nivel_hPa'])
    print('AIRS: países com série',sum(1 for c in cs if c.get('air')),'| tendência global',round(G,2),'ppb/ano')
VAL=None
if os.path.exists('validacao.json'):
    import base64,io
    from PIL import Image
    V=json.load(open('validacao.json',encoding='utf-8'))
    for c in cs:
        v=V['paises'].get(c['en']); c['val']=dict(a=v['airs'],s=v['s5p']) if v else None
    img=''
    if os.path.exists('validacao.png'):
        im=Image.open('validacao.png').convert('RGB'); im=im.resize((760,int(im.height*760/im.width))); b=io.BytesIO(); im.save(b,'JPEG',quality=80); img='data:image/jpeg;base64,'+base64.b64encode(b.getvalue()).decode()
    VAL=dict(ga=V['global_airs'],gs=V['global_s5p'],r=V['pearson'],rho=V['spearman'],conc=V['concordancia_sinal'],rp=V['pearson_paises'],n=V['n_celulas'],img=img)
    print('Validação carregada: r =',V['pearson'])
GP=None
if os.path.exists('gpm_trends.json'):
    from shapely import contains_xy as _cx
    G=json.load(open('gpm_trends.json',encoding='utf-8'))
    ce=np.array([c for c in G['celulas'] if c[3]==1 and abs(c[0])<=60],dtype=float)
    for i,sh in enumerate(shp):
        m=_cx(sh,ce[:,1],ce[:,0])&(ce[:,4]>=300)
        if m.any(): cs[i]['gpm']=dict(h=int((ce[m,2]>0).sum()),s=int((ce[m,2]<0).sum()))
    GP=dict(periodo=G['periodo'],n=G['n_celulas'],sigpct=G['sig_pct'],h=int((ce[:,2]>0).sum()),s=int((ce[:,2]<0).sum()),med=round(float(np.median(np.abs(ce[:,2]))),1),
            lig=G['ligacao'],cells=[[float(r[0]),float(r[1]),round(float(r[2]),1),int(r[4])] for r in ce],ex=G.get('exemplos',[]),anos=list(range(G['periodo'][0],G['periodo'][1]+1)))
    for c in cs:
        pp=G['paises'].get(c['en'])
        if pp: c['gpmS']=dict(s=pp['serie'],sl=pp['slope'],lo=pp['lo'],hi=pp['hi'],q=pp['q'],pd=pp['pct_decada'],sig=pp['sig'],m=pp['media'])
    print('GPM: células significativas (<=60°):',len(ce),'| mais húmidas',GP['h'],'| mais secas',GP['s'])
data={'cells':cells,'countries':cs,'geo':{'type':'FeatureCollection','features':gf},'top':top,'thr':[round(q1,1),round(q2,1)],
      'conts':[{'n':n,'b':b,'lt':lt} for n,b,lt in CONT],'airs':AIRS,'airsC':AC if AIRS else {},'airsK':AK if AIRS else [],'ptmap':{v:k for k,v in PT.items()},'noaa':(json.load(open('noaa_vs_airs.json',encoding='utf-8')) if os.path.exists('noaa_vs_airs.json') else None),'gpm':GP,'meta':dict(built=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).strftime('%Y-%m-%d %H:%M'),end=(META['end'] if 'META' in globals() else None)),'gpmT':(json.load(open('gpm_tempo.json')) if os.path.exists('gpm_tempo.json') else None),'valid':VAL,'per':(json.load(open('periodos.json',encoding='utf-8')) if os.path.exists('periodos.json') else None)}
json.dump({n:CONT[K[i]][0] for i,n in enumerate(names)},open('continentes.json','w',encoding='utf-8'),ensure_ascii=False)
h=open('template.html').read().replace('__DATA__',json.dumps(data,ensure_ascii=False,separators=(',',':')))
_OUT='index.html'
open(_OUT,'w').write(h)
_dir=os.path.dirname(os.path.abspath(_OUT))
_v=D_built if 'D_built' in globals() else __import__('datetime').datetime.now().strftime('%Y%m%d%H%M')
open(os.path.join(_dir,'sw.js'),'w').write("const C='ecocell-"+_v+"';self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(['./','index.html','manifest.webmanifest','icon-192.png','icon-512.png']).catch(()=>{})).then(()=>self.skipWaiting()))});self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==C).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;e.respondWith(fetch(e.request).then(r=>{const cp=r.clone();caches.open(C).then(c=>c.put(e.request,cp));return r}).catch(()=>caches.match(e.request).then(m=>m||caches.match('index.html'))))});")
json.dump({'name':'EcoCell Earth Intelligence','short_name':'EcoCell','start_url':'./','scope':'./','display':'standalone','background_color':'#5fd0e6','theme_color':'#5fd0e6','icons':[{'src':'icon-192.png','sizes':'192x192','type':'image/png'},{'src':'icon-512.png','sizes':'512x512','type':'image/png'}]},open(os.path.join(_dir,'manifest.webmanifest'),'w'))
try:
    import base64,io,re as _re
    from PIL import Image
    _b=_re.search(r'id="logo"[^>]*src="data:image/png;base64,([^"]+)"',h).group(1)
    _im=Image.open(io.BytesIO(base64.b64decode(_b))).convert('RGBA')
    for _n in (192,512):
        _c=Image.new('RGBA',(_n,_n),(95,208,230,255)); _k=int(_n*0.78); _r=_im.resize((_k,int(_k*_im.height/_im.width))); _c.paste(_r,((_n-_r.width)//2,(_n-_r.height)//2),_r); _c.convert('RGB').save(os.path.join(_dir,f'icon-{_n}.png'))
except Exception as _e: print('ícones não gerados:',_e)
print(len(cells),'células',len(h)//1024,'KB','países com dados',sum(c['nc']>0 for c in cs),'mar',int(d.sea.sum()),'fiável',round(d.ch.notna().mean(),2),q1,q2)
print(d.sort_values('rk').head(10).assign(c=lambda x:x.ci.map(lambda i:names[i]))[['c','lat','lon','sea','an','ch','sc']].round(2).to_string())
print('sem dados (grandes):',[(names[i],round(c['a'])) for i,c in enumerate(cs) if c['nc']==0 and c['a']>40])
